    
    %%%%%% NL - MPC State Prediction model %%%%%%%%%%%%
    % Model of Balloon and Pendulum system
    % Inputs: T_i_norm (Tension in Robot string), [n 1]
    %         x_R_0, y_R_0 (Translational x and y position of robots), [n 1]
    %         theta_R_0 (Robot x-y Plane rotation angle about C.O.G. z-axis), [n 1]
    % Total: 4*n
    
    % States:  [x_B_0, y_B_0, z_B_0, phi_b, theta_b, psi_b, phi_p, theta_p ...
    %           x_B_0_dot, y_B_0_dot, z_B_0_dot, phi_b_dot, theta_b_dot, psi_b_dot, phi_p_dot, theta_p_dot]
    % Total: 16
    
    % Max. Set of unmeasured States: x_B_0_dot, y_B_0_dot, z_B_0_dot, phi_b_dot, theta_b_dot, psi_b_dot, phi_p, theta_p, phi_p_dot, theta_p_dot
    % Relevant reference Measured outputs:      x_P_0 y_P_0 z_P_0 (Kinematic relation) 
    % Relevant reference unmeasured Outputs:    phi_P_dot theta_P_dot

    
    function y = NLMPC_BalloonPend_OutFcn(x,u,n,u_wind,params)
    
    y = [pendulum_pos(params,x); x(15); x(16)];
    
    end