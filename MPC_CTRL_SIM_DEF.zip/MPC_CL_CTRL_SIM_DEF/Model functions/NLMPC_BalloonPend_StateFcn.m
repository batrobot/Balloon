
    %%%%%% NL - MPC State Prediction model %%%%%%%%%%%%
    % Model of Balloon and Pendulum system
    % Inputs: T_i_norm (Tension in Robot string), [n 1]
    %         x_R_0, y_R_0 (Translational x and y position of robots), [n 1]
    %         theta_R_0 (Robot x-y Plane rotation angle about C.O.G. z-axis), [n 1]
    % Total: 4*n
    
    % States:  [x_B_0, y_B_0, z_B_0, phi_b, theta_b, psi_b, phi_p, theta_p ...
    %           x_B_0_dot, y_B_0_dot, z_B_0_dot, phi_b_dot, theta_b_dot, psi_b_dot, phi_p_dot, theta_p_dot]
    % Total: 16
    
    % Max. Set of unmeasured States: x_B_0_dot, y_B_0_dot, z_B_0_dot, phi_b_dot, theta_b_dot, psi_b_dot, phi_p, theta_p, phi_p_dot, theta_p_dot
    % Relevant reference Measured outputs:      x_P_0 y_P_0 z_P_0 (Kinematic relation) 
    % Relevant reference unmeasured Outputs:    phi_P_dot theta_P_dot


    function z = NLMPC_BalloonPend_StateFcn(x,u,n,u_wind,params)
 
    % Parameters: [F_B_z, I_B_x, I_B_y, I_B_z, L_i, L_p, d_B_i_vec_mat1_1, d_B_i_vec_mat1_2, d_B_i_vec_mat1_3, d_B_i_vec_mat2_1, d_B_i_vec_mat2_2, d_B_i_vec_mat2_3, d_B_i_vec_mat3_1, d_B_i_vec_mat3_2, d_B_i_vec_mat3_3, d_rob_x, d_rob_y, d_rob_z, d_x_A, d_y_A, d_z_A, g, k_D_B, k_D_P, m_B, m_p, m_v_B, z_COG_R].'

    z = zeros(16+6*n,1);
    
    T_I = T_i_mat(params,x,u);
    
    T_p = T_p_norm(params,T_I,u_wind,x);
    
    z(1:8) = x(9:16);
    
    z(9) = x_B_0_dot_dot(params,T_I,u_wind,T_p,x);
    z(10) = y_B_0_dot_dot(params,T_I,u_wind,T_p,x);
    z(11) = z_B_0_dot_dot(params,T_I,u_wind,T_p,x);
    z(12) = phi_b_0_dot_dot(params,T_I,u_wind,T_p,x);
    z(13) = theta_b_0_dot_dot(params,T_I,u_wind,T_p,x);
    z(14) = psi_b_0_dot_dot(params,T_I,u_wind,T_p,x);
    
    fcn_vec = [x_B_0_dot_dot(params,T_I,u_wind,T_p,x), y_B_0_dot_dot(params,T_I,u_wind,T_p,x), z_B_0_dot_dot(params,T_I,u_wind,T_p,x), phi_b_0_dot_dot(params,T_I,u_wind,T_p,x), theta_b_0_dot_dot(params,T_I,u_wind,T_p,x), psi_b_0_dot_dot(params,T_I,u_wind,T_p,x)];
    z(15) = phi_p_0_dot_dot(params,u_wind,x,fcn_vec);
    z(16) = theta_p_0_dot_dot(params,u_wind,x,fcn_vec);

    z(17:16+3*n) = x(17+3*n:end);
    z(17+3*n:end) = u(n+1:end);

    end  