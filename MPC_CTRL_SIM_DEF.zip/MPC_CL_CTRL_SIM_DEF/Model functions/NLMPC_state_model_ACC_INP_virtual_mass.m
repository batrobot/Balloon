%%%% MPC Equations of motion derivator script  %%%%
% Symbolic variables
%function NLMPC_state_model_ACC_INP_virtual_inputs(n)
n = 3;

syms t 
syms d_B_i_vec_mat [3 n] 
syms T_i_norm [n 1] 
syms T_p_norm 
syms x_B(t) y_B(t) z_B(t) phi_b(t) theta_b(t) psi_b(t)
syms phi_p(t) theta_p(t)
syms theta_R(t) x_R_0(t) y_R_0(t) [n 1] 
syms z_COG_R 
syms g 

syms d_x_A d_y_A d_z_A 
syms L_p 
syms I_B_x I_B_y I_B_z 

syms d_rob_x d_rob_y d_rob_z 
syms L_i 

syms u_wind [3 1] 

syms F_B_z 
syms m_B m_v_B 
syms k_D_B 

syms m_p 
syms k_D_P 

q_0 = [x_B(t), y_B(t), z_B(t), phi_b(t), theta_b(t), psi_b(t), phi_p(t), theta_p(t)];
q_1 = diff(q_0,t);
q_2 = diff(q_1,t);

q_0_rob = [x_R_0(t).',y_R_0(t).',theta_R(t).'];
q_1_rob = diff(q_0_rob);
q_2_rob = diff(q_1_rob);
%% Balloon symbolic definitions

I_B = [I_B_x 0      0   ;
       0     I_B_y  0   ;
       0     0      I_B_z];

r_B(t) = [x_B(t);y_B(t);z_B(t)];
v_B(t) = diff(r_B(t),t);
a_B(t) = diff(v_B(t),t);

EUL_to_ATT(t) = [1 0 -1*sin(theta_b(t));
                 0 cos(phi_b(t)) sin(phi_b(t))*cos(theta_b(t));
                 0 -1*sin(phi_b(t)) cos(phi_b(t))*cos(theta_b(t))];


omega_B(t) = EUL_to_ATT(t)*[diff(phi_b(t),t); diff(theta_b(t),t); diff(psi_b(t),t)];
omega_B_dot(t) = diff(omega_B(t),t);

%Balloon body frame to inertial frame conversion

T_B_1(t) = [ 1 0 0;
                    0 cos(phi_b(t)) sin(phi_b(t));
                    0 -1*sin(phi_b(t)) cos(phi_b(t)) ];
T_B_2(t) = [ cos(theta_b(t)) 0 -1*sin(theta_b(t));
                      0 1 0;
                      sin(theta_b(t)) 0 cos(theta_b(t)) ];
T_B_3(t) = [ cos(psi_b(t)) sin(psi_b(t)) 0 
                    -1*sin(psi_b(t)) cos(psi_b(t)) 0 
                    0 0 1 ];
T_0_B(t) = T_B_1(t)*T_B_2(t)*T_B_3(t);

%% Pendulum %%

r_B_A = [d_x_A;d_y_A;d_z_A];

r_A_P = [0;0;-1*L_p];

T_W_0(t) = [cos(theta_p(t)) sin(phi_p(t))*sin(theta_p(t)) cos(phi_p(t))*sin(theta_p(t));
            0 cos(phi_p(t)) -1*sin(phi_p(t));
            -1*sin(theta_p(t)) sin(phi_p(t))*cos(theta_p(t)) cos(phi_p(t))*cos(theta_p(t))];

%Tension force acting on payload
T_P_vec_pay_W(t) = [0;0;T_p_norm];
T_P_vec_pay_0(t) = T_W_0(t)*T_P_vec_pay_W(t);

%Position, velocity and acceleration of payload

r_B_A_P(t) = r_B(t) + T_0_B(t).'*r_B_A;
v_B_A_P(t) = diff(r_B_A_P(t),t);
a_B_A_P(t) = diff(v_B_A_P(t),t);
r_p(t) = r_B(t) + T_0_B(t).'*r_B_A + T_W_0(t)*r_A_P;
v_p(t) = diff(r_p(t),t);
a_p(t) = diff(v_p(t),t);


%% Symbolic variable definitions
syms x_B_0 y_B_0 z_B_0 phi_b_0 theta_b_0 psi_b_0 phi_p_0 theta_p_0 
syms x_B_0_dot y_B_0_dot z_B_0_dot phi_b_0_dot theta_b_0_dot psi_b_0_dot phi_p_0_dot theta_p_0_dot 
syms x_B_0_dot_dot y_B_0_dot_dot z_B_0_dot_dot phi_b_0_dot_dot theta_b_0_dot_dot psi_b_0_dot_dot phi_p_0_dot_dot theta_p_0_dot_dot 

sym_od_0 = [x_B_0, y_B_0, z_B_0, phi_b_0, theta_b_0, psi_b_0, phi_p_0, theta_p_0];
sym_od_1 = [x_B_0_dot, y_B_0_dot, z_B_0_dot, phi_b_0_dot, theta_b_0_dot, psi_b_0_dot, phi_p_0_dot, theta_p_0_dot];
sym_od_2 = [x_B_0_dot_dot, y_B_0_dot_dot, z_B_0_dot_dot, phi_b_0_dot_dot, theta_b_0_dot_dot, psi_b_0_dot_dot, phi_p_0_dot_dot, theta_p_0_dot_dot];

syms x_R_0_sym y_R_0_sym theta_R_sym [n 1]
syms v_x_R_0_sym v_y_R_0_sym theta_R_dot_sym [n 1]
syms a_x_R_0_sym a_y_R_0_sym theta_R_dot_dot_sym [n 1]

sym_od_rob_0 = [x_R_0_sym.',y_R_0_sym.',theta_R_sym.'];
sym_od_rob_1 = [v_x_R_0_sym.',v_y_R_0_sym.',theta_R_dot_sym.'];
sym_od_rob_2 = [a_x_R_0_sym.',a_y_R_0_sym.',theta_R_dot_dot_sym.'];

%% Balloon equations of motion %

syms T_i_mat_B_0 [3 n] 

F_D_B(t) = -0.5*k_D_B.*(formula(v_B(t))-u_wind).*norm(formula(v_B(t))-u_wind);

% Define T_P as function of state variables
T_P_vec_B_W = [0;0;-1*T_p_norm];
T_P_vec_B_0 = T_W_0(t)*T_P_vec_B_W;

LHS_eq_trans = [m_v_B;m_v_B;m_v_B].*a_B(t);
LHS_eq_rot = I_B*diff(omega_B(t),t) + cross(omega_B(t),(I_B*omega_B(t)));
RHS_eq_trans = F_D_B(t) + T_P_vec_B_0 + sum(T_i_mat_B_0,2) + [0;0;(F_B_z - m_B*g)];
RHS_eq_rot = cross(r_B_A,T_0_B(t)*T_P_vec_B_0);
for j = 1:1:n
     RHS_eq_rot = RHS_eq_rot + cross(d_B_i_vec_mat(:,j),T_0_B(t)*T_i_mat_B_0(:,j));
end

%Final EOM

EOM_B = formula([LHS_eq_trans;LHS_eq_rot] == [RHS_eq_trans;RHS_eq_rot]);
%simplify(EOM_B)

EOM_B_sym = subs(EOM_B,[q_0,q_1,q_2],[sym_od_0,sym_od_1,sym_od_2]);
SOL_B = solve(EOM_B_sym,[x_B_0_dot_dot, y_B_0_dot_dot, z_B_0_dot_dot, phi_b_0_dot_dot, theta_b_0_dot_dot, psi_b_0_dot_dot]);

[x_B_0_dot_dot, y_B_0_dot_dot, z_B_0_dot_dot, phi_b_0_dot_dot, theta_b_0_dot_dot, psi_b_0_dot_dot] = deal(SOL_B.x_B_0_dot_dot,SOL_B.y_B_0_dot_dot,SOL_B.z_B_0_dot_dot,SOL_B.phi_b_0_dot_dot,SOL_B.theta_b_0_dot_dot,SOL_B.psi_b_0_dot_dot);

%% Payload dynamics equations of motion % 

F_D_P(t) = -0.5*k_D_P.*(formula(v_p(t))-u_wind).*norm(formula(v_p(t))-u_wind);

%Final EOM

EOM_P = m_p.*a_p(t) == T_P_vec_pay_0(t) - [0;0;m_p*g] + F_D_P(t);

EOM_P_sym_fcn = subs(EOM_P,[q_0,q_1,q_2],[sym_od_0,sym_od_1,sym_od_2]);
SOL_P_fcn = solve(EOM_P_sym_fcn,[phi_p_0_dot_dot, theta_p_0_dot_dot, T_p_norm],ReturnConditions=false);

%Enable to solve explicity directly using precomputed Balloon EOM solutions
%EOM_P_sym_exp = subs(EOM_P,[q_0,q_1,q_2],[sym_od_0,sym_od_1,[x_B_0_dot_dot, y_B_0_dot_dot, z_B_0_dot_dot, phi_b_0_dot_dot, theta_b_0_dot_dot, psi_b_0_dot_dot, phi_p_0_dot_dot, theta_p_0_dot_dot]]);
%SOL_P = solve(EOM_P_sym,[phi_p_0_dot_dot, theta_p_0_dot_dot, T_p_norm]);

T_p_norm_sub = solve(T_p_norm == subs(SOL_P_fcn.T_p_norm,[sym_od_2],[x_B_0_dot_dot, y_B_0_dot_dot, z_B_0_dot_dot, phi_b_0_dot_dot, theta_b_0_dot_dot, psi_b_0_dot_dot, phi_p_0_dot_dot, theta_p_0_dot_dot]),T_p_norm);%SOL_P.T_p_norm;
phi_p_0_dot_dot = SOL_P_fcn.phi_p_0_dot_dot;
theta_p_0_dot_dot = SOL_P_fcn.theta_p_0_dot_dot;

%% Calculate Rope Tension interaction for state equations %%%

T_i_mat_B_0_sub = [];
L_con_EQN = [];
V_con_EQN = [];
A_con_EQN = [];
x_R_vec = formula(x_R_0(t));
y_R_vec = formula(y_R_0(t));
theta_R_vec = formula(theta_R(t));
for i=1:1:n
    x_R_i_0(t)= x_R_vec(i);
    y_R_i_0(t) = y_R_vec(i);
    theta_R_i(t) = theta_R_vec(i);

    r_B_I_mat = d_B_i_vec_mat(:,i);
    r_B_i_A = formula(r_B(t) + T_0_B(t).'*r_B_I_mat);
    [x_B_i(t), y_B_i(t), z_B_i(t)] = deal(r_B_i_A(1),r_B_i_A(2),r_B_i_A(3));


    T_ROB_0(t) = [cos(theta_R_i(t)) -sin(theta_R_i(t)) 0;
                  sin(theta_R_i(t)) cos(theta_R_i(t))  0;
                  0               0                1];
    r_rob_CG_A = [d_rob_x; d_rob_y; d_rob_z];
    r_rob_CG_A_0 = T_ROB_0(t)*r_rob_CG_A;

    delta_r_i(t) =[(x_R_i_0(t)+r_rob_CG_A_0(1)-x_B_i(t));
                   (y_R_i_0(t)+r_rob_CG_A_0(2)-y_B_i(t));
                   (z_COG_R+d_rob_z-z_B_i(t))];

    L_con_EQN = [L_con_EQN; subs(dot(delta_r_i(t),delta_r_i(t)) - L_i.^2,[q_0,q_0_rob],[sym_od_0,sym_od_rob_0])];
    V_con_EQN = [V_con_EQN; subs(diff((dot(delta_r_i(t),delta_r_i(t)) - L_i.^2),t),[q_0,q_0_rob,q_1,q_1_rob],[sym_od_0,sym_od_rob_0,sym_od_1,sym_od_rob_1])];
    A_con_EQN = [A_con_EQN; subs(diff(diff((dot(delta_r_i(t),delta_r_i(t)) - L_i.^2),t),t),[q_0,q_0_rob,q_1,q_1_rob,q_2,q_2_rob],[sym_od_0,sym_od_rob_0,sym_od_1,sym_od_rob_1,sym_od_2,sym_od_rob_2])]; % sym_od_2 replaced with [x_B_0_dot_dot, y_B_0_dot_dot, z_B_0_dot_dot, phi_b_0_dot_dot, theta_b_0_dot_dot, psi_b_0_dot_dot, phi_p_0_dot_dot, theta_p_0_dot_dot]
    
    T_ROPE_I_dir_0 = subs((delta_r_i(t)/L_i),[q_0,q_0_rob],[sym_od_0,sym_od_rob_0]);
        
    T_i_vec_rob_0 = T_i_norm(i).*T_ROPE_I_dir_0;
    T_i_mat_B_0_sub = horzcat(T_i_mat_B_0_sub,T_i_vec_rob_0);

    clearvars T_i_vec_rob_0 x_B_i y_B_i z_B_i x_R_i_0 y_R_i_0 theta_R_i r_B_i_A r_B_I_mat
end

%% Prepare State evolution functions for export to StateFcn
syms x [16 + 6*n 1]
syms u [4*n 1]
sym_od_states_exp = [sym_od_0, sym_od_1, sym_od_rob_0, sym_od_rob_1];
sym_od_inp = [T_i_norm.',a_x_R_0_sym.',a_y_R_0_sym.',theta_R_dot_dot_sym.'];

T_p = subs(T_p_norm_sub,[sym_od_states_exp,sym_od_inp],[x.',u.']);
T_i_mat = subs(T_i_mat_B_0_sub,[sym_od_states_exp,sym_od_inp],[x.',u.']);
L_con_EQN = subs(L_con_EQN,[sym_od_states_exp,sym_od_inp],[x.',u.']);
V_con_EQN = subs(V_con_EQN,[sym_od_states_exp,sym_od_inp],[x.',u.']);
A_con_EQN = subs(A_con_EQN,[sym_od_states_exp,sym_od_inp],[x.',u.']);

%Convert to matlab functions

EOM_exp = vertcat(x_B_0_dot_dot, y_B_0_dot_dot, z_B_0_dot_dot, phi_b_0_dot_dot, theta_b_0_dot_dot, psi_b_0_dot_dot, phi_p_0_dot_dot, theta_p_0_dot_dot);
EOM_exp = subs(EOM_exp,[sym_od_states_exp,sym_od_inp],[x.',u.']);

param_var = setdiff([symvar(EOM_exp),symvar(T_i_mat),symvar(T_p)],[reshape(T_i_mat_B_0.',1,[]),u_wind.',T_p_norm,u.',x.',sym_od_2])

matlabFunction(T_p,'File','T_p_norm','Vars',{param_var,T_i_mat_B_0,u_wind,x});
matlabFunction(T_i_mat,'File','T_i_mat','Vars',{param_var,x,u});
matlabFunction(L_con_EQN,'File','L_con_EQN','Vars',{param_var,x});
matlabFunction(V_con_EQN,'File','V_con_EQN','Vars',{param_var,x});
matlabFunction(A_con_EQN,'File','A_con_EQN','Vars',{param_var,sym_od_2(1:6),x,u});

for it=1:1:length(EOM_exp)
    if it > 6
        matlabFunction(EOM_exp(it),'File',char(sym_od_2(it)),'Vars',{param_var,u_wind,x,sym_od_2(1:6)})
    else
        matlabFunction(EOM_exp(it),'File',char(sym_od_2(it)),'Vars',{param_var,T_i_mat_B_0,u_wind,T_p_norm,x})
    end
end

save State_model_EOM_vars.mat EOM_B_sym EOM_P_sym_fcn F_D_B F_D_P param_var L_con_EQN V_con_EQN A_con_EQN
save State_model_EOM_solved.mat x_B_0_dot_dot y_B_0_dot_dot z_B_0_dot_dot phi_b_0_dot_dot theta_b_0_dot_dot psi_b_0_dot_dot phi_p_0_dot_dot theta_p_0_dot_dot T_p_norm_sub T_i_mat_B_0_sub

%% Prepare outputfunction

 x_P_vec = subs(r_p(t),q_0,x(1:8).');
 matlabFunction(x_P_vec,'File','pendulum_pos','Vars',{param_var,x})

%% Calculate Jacobians for Balloon and Pendulum statest only (16+6*n states) -> COMPUTATIONALLY EXPENSIVE!
%{
params = load('model_params.mat').param_vec;

EOM_J_exp = subs(EOM_exp,sym_od_2(1:6),EOM_exp(1:6).');
EOM_J_exp = subs(EOM_J_exp,param_var,params);
T_p = subs(T_p,param_var,params);
T_i_mat = subs(T_i_mat,param_var,params);
for i=1:length(EOM_J_exp)
    EOM_J_exp(i) = subs(EOM_J_exp(i),T_p_norm,T_p);
    EOM_J_exp(i) = subs(EOM_J_exp(i),reshape(T_i_mat_B_0.',1,[]),reshape(T_i_mat',1,[]));
end
A = [[zeros(8),eye(8),zeros(8,6*n)];jacobian(EOM_J_exp.',x.');[zeros(6*n,16+3*n),[eye(3*n);zeros(3*n)]]];
B = [zeros(8,4*n);jacobian(EOM_J_exp.',u.');zeros(3*n,4*n);[zeros(3*n,n),eye(3*n)]];
C = [jacobian(x_P_vec.',x.'); [zeros(2,14),eye(2,2),zeros(2,6*n)]];
D = zeros(5,4*n);

%matlabFunction(EOM_J_exp(1),'File','Jacobians/FULL_EOM','Optimize',false,'Vars',{x,u,u_wind})
%matlabFunction(A(9,:),'File','Jacobians/NL_A','Optimize',false,'Vars',{x,u,u_wind})
%matlabFunction(B,'File','Jacobians/NL_B','Optimize',false,'Vars',{x,u,u_wind})
%matlabFunction(C,'File','Jacobians/NL_C','Optimize',false,'Vars',{x,u,u_wind})
%matlabFunction(D,'File','Jacobians/NL_D','Optimize',false,'Vars',{x,u,u_wind})
%}

%end

