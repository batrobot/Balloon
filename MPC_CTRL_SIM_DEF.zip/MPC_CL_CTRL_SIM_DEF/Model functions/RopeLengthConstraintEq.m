function ceq = RopeLengthConstraintEq(X,U,data,n,u_wind,params)
%
% Dynamic input constraints
%
%Specifies relation contraitns between virtual tension force input and
%physical robot position/velocity/acceleration

p = data.PredictionHorizon;
ceq = [];% zeros(p*n,1);
for k=1:1:p
    %T_I = T_i_mat(params,X(k+1,:).',U(k,:).');
    %T_p = T_p_norm(params,T_I,u_wind,X(k+1,:).');
    %fcn_vec = [x_B_0_dot_dot(params,T_I,u_wind,T_p,X(k+1,:).'), y_B_0_dot_dot(params,T_I,u_wind,T_p,X(k+1,:).'), z_B_0_dot_dot(params,T_I,u_wind,T_p,X(k+1,:).'), phi_b_0_dot_dot(params,T_I,u_wind,T_p,X(k+1,:).'), theta_b_0_dot_dot(params,T_I,u_wind,T_p,X(k+1,:).'), psi_b_0_dot_dot(params,T_I,u_wind,T_p,X(k+1,:).')];
    % Length constraint of first order
    ceq = [ceq; L_con_EQN(params,X(k+1,:).')];
    % Acceleration cosntraint of second order
    %ceq(1+(k-1)*n:k*n,:) = A_con_EQN(params,fcn_vec,X(k+1,:).',U(k,:).');
end  

end