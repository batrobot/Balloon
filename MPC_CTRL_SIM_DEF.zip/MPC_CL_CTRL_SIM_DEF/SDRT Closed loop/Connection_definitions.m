%Real Time Connection definitions

IP = ["'192.168.0.102'" "'192.168.0.103'" "'192.168.0.104'"];
P_Target = [4210, 4210, 4210];

