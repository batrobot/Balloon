% Run MPC_Control_exec_fcn.m %
clc;
clear;

% Define number of robts considered
n = 3;
% Create model parameters
run('Model_parameter_script_PVC_Balloon.m')
% Run UDP connection definitions
run('Real_time_CTRL/Connection_definitions.m')
%Create model functions
%NLMPC_state_model_ACC_INP_virtual_inputs(n)

% Define output reference
ref = [0.3,-0.3,0.7,0,0];
% Define sample Time, prediction horizon and MPC-Linear option for controller
Ts = 1.0;
p = 15; %12
c = 15;
MPCopt = 'timevarying';
% Define simulation parameters
SL_file = 'CL_PLANT_3_rob_ACC_IN_direct_virtual_mass_3D';
T_steps = 10; %40;%2*p;
a_max = 0.1;
T_v_disc = 0.05;

u_wind = [-0.5;-0.5;0];

sim_flag = true;
%% Continous Closed loop simulation

%param = load('model_params.mat').param_vec;

for i = 1:T_steps
    if i <= 5
        ref_t(i,:) = [0.2 -0.2 0.2 0 0];
    elseif i <= 10
        ref_t(i,:) = [0.4 -0.4 0.4 0 0];
    elseif i <= 15
        ref_t(i,:) = [0.6 -0.6 0.4 0 0];
    elseif i <= 20
        ref_t(i,:) = [0.8 -0.8 0.2 0 0];
    elseif i <= T_steps
        ref_t(i,:) = [1.0 -1.0 0.1 0 0];
    end
end

step_preview = 0; %9; %Up to p-1

u_0 = load('state_initial_cond.mat').u_init;
x_0 = load('state_initial_cond.mat').x_init;

tic
[nlobj_CG,opt,MPC_params_CG,CL_simout,u_cl,x_cl] = MPC_Control_exec_fcn_scaled(u_wind,param_vec,x_0,u_0,n,ref,T_steps,a_max,SL_file,Ts,p,c,MPCopt,sim_flag,step_preview);
toc

%% MPC Code generation for Real-Time

%param = load('model_params.mat').param_vec;

u_0 = load('state_initial_cond.mat').u_init;
x_0 = load('state_initial_cond.mat').x_init;

[CL_simout_2,u_cl_2,x_cl_2] = MPC_Code_generation(nlobj_CG,MPC_params_CG,x_0,u_0,n,ref,T_steps,SL_file,Ts)


%% Plot Closed loop results

figure
for i = 1:length(out_backup)
    plot(out_backup(i,1).pay_outputs)
    hold on;
    for j=1:5
        yline(ref(j),'--')
        hold on;
    end
end
legend('X_{POS}','Y_{POS}','Z_{POS}','Phi V','Theta V','X_{REF}','Y_{REF}','Z_{REF}','Phi V_{REF}','Theta V_{REF}')

figure
for i = 1:length(out_backup)
    plot(out_backup(i,1).T_i)
    hold on;
end
plot((0:Ts:Ts*(T_steps-1)).',u_cl(:,1:n))

plot((0:Ts:Ts*(T_steps-1)).',x_cl(:,27:29))

figure
plot(u_cl(:,n+1:n+3))
hold on;
plot(u_cl(:,2*n+1:2*n+3))
hold on;
plot(u_cl(:,3*n+1:3*n+3))
legend('ROBOT 1 X_{ACC}','ROBOT 2 X {ACC}','ROBOT 3 X_{ACC}','ROBOT 1 Y_{POS}','ROBOT 2_Y_{POS}','ROBOT 3 Y_{POS}','ROBOT 1 Z_{POS}','ROBOT 2 Z_{POS}','ROBOT 3 Z_{POS}')

figure
for i=1:length(out_backup)
    plot(out_backup(i,1).states.Data(:,26:29))
end


figure
for i = 1:length(out_backup)
    plot(out_backup(i,1).states)
    hold on;
end

%% Save Simulation output data
save 'OL_0_1_acc_15_secs.mat' out ACC_IN
%CL_simout opt nlobj_CG u_0 x_0 MPC_params_CG a_max T_steps ref_t u_cl x_cl -mat
