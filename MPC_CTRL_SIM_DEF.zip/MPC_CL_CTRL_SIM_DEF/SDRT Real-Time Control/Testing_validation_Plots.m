%Acceleration analysis
% 
%clear;
fpass = 0.5;

%out = load('Test_Data_recording_10_03_22\Save_data\Test_7\10_3_22_Test_7_a_y_neg_0.2_signal_1').out;
run('Model_parameter_script_PVC_Balloon.m')

u_wind = [0;0;0];
n = 3;

%UPDATE START POSITIONS FROM READOUT
%x_I_start = out.simout.Data(1,17:19) - out.simout.Data(1,1);
%y_I_start = out.simout.Data(1,20:22) - out.simout.Data(1,2);

v_x_lp = [lowpass(out.simout.Data(:,26),fpass,20),lowpass(out.simout.Data(:,27),fpass,20),lowpass(out.simout.Data(:,28),fpass,20)];
v_x_raw = [out.simout.Data(:,26),out.simout.Data(:,27),out.simout.Data(:,28)];

v_y_lp = [lowpass(out.simout.Data(:,29),fpass,20),lowpass(out.simout.Data(:,30),fpass,20),lowpass(out.simout.Data(:,31),fpass,20)];
v_y_raw = [out.simout.Data(:,29),out.simout.Data(:,30),out.simout.Data(:,31)];

t = out.simout.Time;

figure
plot(t,v_x_lp);
hold on;
plot(t,v_y_lp);

for j = 1:n
    % Acceleration from Velocity
    for i=1:length(t)
        if i > 2 && i < length(t)-1
            acc_x_raw(i,j)=(v_x_raw(i-2,j)-8*v_x_raw(i-1,j)+8*v_x_raw(i+1,j)-v_x_raw(i+2,j))/(12*mean(diff(t)));
            acc_x_lp(i,j)=(v_x_lp(i-2,j)-8*v_x_lp(i-1,j)+8*v_x_lp(i+1,j)-v_x_lp(i+2,j))/(12*mean(diff(t)));
            acc_y_raw(i,j)=(v_y_raw(i-2,j)-8*v_y_raw(i-1,j)+8*v_y_raw(i+1,j)-v_y_raw(i+2,j))/(12*mean(diff(t)));
            acc_y_lp(i,j)=(v_y_lp(i-2,j)-8*v_y_lp(i-1,j)+8*v_y_lp(i+1,j)-v_y_lp(i+2,j))/(12*mean(diff(t)));
        else
            acc_x_raw(i,j)=0;
            acc_x_lp(i,j)=0;
            acc_y_raw(i,j)=0;
            acc_y_lp(i,j)=0;
        end
    end
end

figure
plot(t,acc_x_lp);
hold on;
plot(t,acc_y_lp);

%%

v_0_vec_b = zeros(1,6); %out.simout.Data(1,9:14); %  %; %zeros(1,6); 
v_0_vec_p = zeros(1,3); %[out.simout.Data(1,38:39).*[-L_i L_i] 0]; %; %; 

% Set payload start position
r_p_0 = zeros(1,2); %out.simout.Data(1,35:36) - out.simout.Data(1,1:2); %

%%

u1 = [acc_x_lp(:,1) acc_y_lp(:,1) zeros(length(t),1)];
u2 = [acc_x_lp(:,2) acc_y_lp(:,2) zeros(length(t),1)];
u3 = [acc_x_lp(:,3) acc_y_lp(:,3) zeros(length(t),1)];

ds = Simulink.SimulationData.Dataset;
ds = ds.setElement(1, timeseries(u1,t)); % First element
ds = ds.setElement(2, timeseries(u2,t)); % Second element
ds = ds.setElement(3, timeseries(u3,t)); % Third element

in = Simulink.SimulationInput('CL_PLANT_3_rob_ACC_IN_direct_v_init_test');
in = in.setExternalInput('ds.getElement(1),ds.getElement(2),ds.getElement(3)');
in = in.setModelParameter('StopTime', num2str(t(end)));

out_sim = sim(in);

%% Plot results

%Balloon X-Y-Z
figure
plot(out_sim.tout,out_sim.states.Data(:,1),t,out.simout.Data(:,1)-out.simout.Data(1,1))
hold on;
plot(out_sim.tout,out_sim.states.Data(:,2),t,out.simout.Data(:,2)-out.simout.Data(1,2));
hold on;
plot(out_sim.tout,out_sim.states.Data(:,3),t,out.simout.Data(:,3));

%Balloon phi-theta-psi
figure
plot(out_sim.tout,out_sim.states.Data(:,4),t,out.simout.Data(:,5)-out.simout.Data(1,5))
hold on;
plot(out_sim.tout,out_sim.states.Data(:,5),t,out.simout.Data(:,4)-out.simout.Data(1,4));
hold on;
plot(out_sim.tout,out_sim.states.Data(:,6),t,out.simout.Data(:,6)-out.simout.Data(1,6));


%Payload Angles
figure
plot(out_sim.tout,out_sim.states.Data(:,7),t,out.simout.Data(:,7)-out.simout.Data(1,7))
hold on;
plot(out_sim.tout,out_sim.states.Data(:,8),t,out.simout.Data(:,8)-out.simout.Data(1,8));


%Payload Angular velocities
figure
plot(out_sim.tout,out_sim.states.Data(:,15),t,out.simout.Data(:,15)-out.simout.Data(1,15))
hold on;
plot(out_sim.tout,out_sim.states.Data(:,16),t,out.simout.Data(:,16)-out.simout.Data(1,16));


%Payload position
output_plot = squeeze(out_sim.pay_outputs.Data);
figure
plot(out_sim.tout,output_plot(1:2,:))
hold on;
plot(out_sim.tout,output_plot(3,:)-h_p_start+out.simout.Data(1,37))
hold on;
plot(t,out.simout.Data(:,35:36)-out.simout.Data(1,35:36))
hold on;
plot(t,out.simout.Data(:,37))
legend('Simulation x_{P}', 'Simulation y_{P}', 'Simulation z_{P}','Testing x_{P}', 'Testing y_{P}', 'Testing z_{P}' )

%% CDC paper plotting

hfig1 = figure(1);
set(hfig1,'Position',[70,70,650,500]);

line_width = 1;

[out_1,out_sim_1] = deal(out,out_sim) %deal(load('A_X_0_2_validation_virtual_mass_C_mass_0_3.mat').out, load('A_X_0_2_validation_virtual_mass_C_mass_0_3.mat').out_sim);
[out_2,out_sim_2] = deal(out,out_sim)  %deal(load('A_Y_0_2_validation_virtual_mass_C_mass_0_3.mat').out, load('A_Y_0_2_validation_virtual_mass_C_mass_0_3.mat').out_sim);
[out_3,out_sim_3] = deal(out,out_sim)  %deal(load('A_Z_0_2_validation_virtual_mass_C_mass_0_3.mat').out, load('A_Z_0_2_validation_virtual_mass_C_mass_0_3.mat').out_sim);

%%
output_plot = squeeze(out_sim_1.pay_outputs.Data);

subplot(3,1,1)
value = output_plot(1,:);
plot(out_sim_1.tout,value,'-.','LineWidth',line_width,'Color','b')
hold on
grid on
plot(out_1.simout.Time,out_1.simout.Data(:,35)-out_1.simout.Data(1,35),'LineWidth',line_width,'Color','r')
legend('Simulation $x_{P}$', 'Testing $x_{P}$','Location', 'southeast', 'Orientation', 'vertical', 'Box', 'on','FontSize', 9,'Interpreter','latex')
axis([-inf,inf, min(value) - 0.4, max(value) + 0.4])
tit = title('\textbf{Open-loop MPC trajectory: Payload response}','FontSize',12);
set(tit,'Interpreter','latex');
ylabel('Position (m)','FontSize',10,'Interpreter','latex')

output_plot = squeeze(out_sim_2.pay_outputs.Data);

subplot(3,1,2)
value = output_plot(2,:);
plot(out_sim_2.tout,value,'-.','LineWidth',line_width,'Color','b')
hold on
grid on
plot(out_2.simout.Time,out_2.simout.Data(:,36)-out_2.simout.Data(1,36),'LineWidth',line_width,'Color','r')
legend('Simulation $y_{P}$', 'Testing $y_{P}$','Location', 'southeast', 'Orientation', 'vertical', 'Box', 'on','FontSize', 9,'Interpreter','latex')
axis([-inf,inf, min(value) - 0.4, max(value) + 0.4])
%tit = title('\textbf{Case 2: Payload response}','FontSize',12);
%set(tit,'Interpreter','latex');
ylabel('Position (m)','FontSize',10,'Interpreter','latex')


output_plot = squeeze(out_sim_3.pay_outputs.Data);

subplot(3,1,3)
value = output_plot(3,:);
plot(out_sim_3.tout,value-value(1)+out_3.simout.Data(1,37),'-.','LineWidth',line_width,'Color','b')
hold on
grid on
plot(out_3.simout.Time,out_3.simout.Data(:,37),'LineWidth',line_width,'Color','r')
legend('Simulation $z_{P}$', 'Testing $z_{P}$','Location', 'southeast', 'Orientation', 'vertical', 'Box', 'on','FontSize', 9,'Interpreter','latex')
axis([-inf,inf, min(value) - 0.4, max(value) + 0.4])
%tit = title('\textbf{Case 3: Payload response}','FontSize',12);
%set(tit,'Interpreter','latex');
ylabel('Position (m)','FontSize',10,'Interpreter','latex')
xlabel('Time (s)')

%%


hfig1 = figure(1);
set(hfig1,'Position',[70,70,650,500]);

state_plot = squeeze(out_sim_1.states.Data);

subplot(3,1,1)
value = state_plot(:,1);
plot(out_sim_1.tout,value,'-.','LineWidth',line_width,'Color','b')
hold on
grid on
plot(out_1.simout.Time,out_1.simout.Data(:,2)-out_1.simout.Data(1,2),'LineWidth',line_width,'Color','r')
legend('Simulation $x_{B}$', 'Testing $x_{B}$','Location', 'southeast', 'Orientation', 'vertical', 'Box', 'on','FontSize', 9,'Interpreter','latex')
axis([-inf,inf, min(value) - 0.4, max(value) + 0.4])
tit = title('\textbf{Diagonal movement: Balloon response}','FontSize',12);
set(tit,'Interpreter','latex');
ylabel('Position (m)','FontSize',10,'Interpreter','latex')

state_plot = squeeze(out_sim_2.states.Data);

subplot(3,1,2)
value = state_plot(:,2);
plot(out_sim_2.tout,value,'-.','LineWidth',line_width,'Color','b')
hold on
grid on
plot(out_2.simout.Time,out_2.simout.Data(:,2)-out_2.simout.Data(1,2),'LineWidth',line_width,'Color','r')
legend('Simulation $y_{B}$', 'Testing $y_{B}$','Location', 'southeast', 'Orientation', 'vertical', 'Box', 'on','FontSize', 9,'Interpreter','latex')
axis([-inf,inf, min(value) - 0.4, max(value) + 0.4])
%tit = title('\textbf{Case 2: Balloon response}','FontSize',12);
%set(tit,'Interpreter','latex');
ylabel('Position (m)','FontSize',10,'Interpreter','latex')


state_plot = squeeze(out_sim_3.states.Data);

subplot(3,1,3)
value = state_plot(:,3);
plot(out_sim_3.tout,value-value(1)+out_3.simout.Data(1,3),'-.','LineWidth',line_width,'Color','b')
hold on
grid on
plot(out_3.simout.Time,out_3.simout.Data(:,3),'LineWidth',line_width,'Color','r')
legend('Simulation $z_{B}$', 'Testing $z_{B}$','Location', 'southeast', 'Orientation', 'vertical', 'Box', 'on','FontSize', 9,'Interpreter','latex')
axis([-inf,inf, min(value) - 0.4, max(value) + 0.4])
%tit = title('\textbf{Case 3: Balloon response}','FontSize',12);
%set(tit,'Interpreter','latex');
ylabel('Position (m)','FontSize',10,'Interpreter','latex')
xlabel('Time (s)')

tightfig(hfig1);

%%

hfig1 = figure(1);
set(hfig1,'Position',[70,70,850,600]);

state_plot = squeeze(out_sim_1.states.Data);

subplot(3,1,1)
value = state_plot(:,7:8)*(180/pi);
plot(out_sim_1.tout,value(:,1),'-.','LineWidth',line_width,'Color','b')
hold on
grid on
%plot(out_sim_1.tout,value(:,2),'-.','LineWidth',line_width,'Color','r')
plot(out_1.simout.Time,(out_1.simout.Data(:,7)-out_1.simout.Data(1,7))*(180/pi),'LineWidth',line_width,'Color','b')
%plot(out_1.simout.Time,(out_1.simout.Data(:,8)-out_1.simout.Data(1,8))*(180/pi),'LineWidth',line_width,'Color','r')
legend('Simulation $\phi_{P}$', 'Testing $\phi_{P}$','Location', 'south', 'Orientation', 'horizontal', 'Box', 'off','FontSize', 9,'Interpreter','latex')
axis([-inf,inf, min(min(value)) - 2, max(max(value)) + 3])
tit = title('\textbf{Diagonal movement: Payload tether angles}','FontSize',12);
set(tit,'Interpreter','latex');
ylabel('Angle (deg)','FontSize',10,'Interpreter','latex')


state_plot = squeeze(out_sim_2.states.Data);

subplot(3,1,2)
value = state_plot(:,7:8)*(180/pi);
%plot(out_sim_2.tout,value(:,1),'-.','LineWidth',line_width,'Color','b')
hold on
grid on
plot(out_sim_2.tout,value(:,2),'-.','LineWidth',line_width,'Color','r')
%plot(out_2.simout.Time,(out_2.simout.Data(:,7)-out_2.simout.Data(1,7))*(180/pi),'LineWidth',line_width,'Color','b')
plot(out_2.simout.Time,(out_2.simout.Data(:,8)-out_2.simout.Data(1,8))*(180/pi),'LineWidth',line_width,'Color','r')
legend('Simulation $\theta_{P}$', 'Testing $\theta_{P}$','Location', 'south', 'Orientation', 'horizontal', 'Box', 'off','FontSize', 9,'Interpreter','latex')
axis([-inf,inf, min(min(value)) - 2, max(max(value)) + 3])
%tit = title('\textbf{Case 2: Payload tether angles}','FontSize',12);
%set(tit,'Interpreter','latex');
ylabel('Angle (deg)','FontSize',10,'Interpreter','latex')


%state_plot = squeeze(out_sim_3.states.Data);

%subplot(3,1,3)
%value = state_plot(:,7:8)*(180/pi);
%plot(out_sim_3.tout,value(:,1),'-.','LineWidth',line_width,'Color','b')
%hold on
%grid on
%plot(out_sim_3.tout,value(:,2),'-.','LineWidth',line_width,'Color','r')
%plot(out_3.simout.Time,(out_3.simout.Data(:,7)-out_3.simout.Data(1,7))*(180/pi),'LineWidth',line_width,'Color','b')
%plot(out_3.simout.Time,(out_3.simout.Data(:,8)-out_3.simout.Data(1,8))*(180/pi),'LineWidth',line_width,'Color','r')
%legend('Simulation $\phi_{P}$', 'Simulation $\theta_{P}$', 'Testing $\phi_{P}$', 'Testing $\theta_{P}$','Location', 'south', 'Orientation', 'horizontal', 'Box', 'off','FontSize', 9,'Interpreter','latex')
%axis([-inf,inf, min(min(value)) - 2, max(max(value)) + 2])
%tit = title('\textbf{Case 3: Payload tether angles}','FontSize',12);
%set(tit,'Interpreter','latex');
%ylabel('Angle (deg)','FontSize',10,'Interpreter','latex')
%xlabel('Time (s)','FontSize',10,'Interpreter','latex')


tightfig(hfig1);

%%
saveas(hfig1, 'figures\VAL_OL_command_1_p_outputs.fig');
% print(hfig1, '-painters', '-dsvg', 'figures\CONST_REF_FINAL_plot_outputs.svg');
print(hfig1, '-painters', '-dpdf', 'figures\VAL_OL_command_1_p_outputs.pdf');


%%


hfig2 = figure(2);
set(hfig2,'Position',[70,70,600,450]);


subplot(2,1,1)
plot(out_1.simout.Time,out_1.simout.Data(:,26:28),'LineWidth',line_width)
grid on;
legend('UGV 1 Velocity $\dot{x}_{1}$', 'UGV 2 Velocity $\dot{x}_{2}$','UGV 3 Velocity $\dot{x}_{3}$','Location', 'southeast', 'Orientation', 'vertical', 'Box', 'on','FontSize', 9,'Interpreter','latex')
axis([-inf,inf, -0.5, 0.5])
tit = title('\textbf{Open-loop MPC Trajectory: X-direction UGV velocities}','FontSize',12);
set(tit,'Interpreter','latex');
ylabel('Velocity (m/s)','FontSize',10,'Interpreter','latex')

subplot(2,1,2)
plot(out_2.simout.Time,out_2.simout.Data(:,29:31),'LineWidth',line_width)
grid on;
legend('UGV 1 Velocity $\dot{y}_{1}$', 'UGV 2 Velocity $\dot{y}_{2}$','UGV 3 Velocity $\dot{y}_{3}$','Location', 'southeast', 'Orientation', 'vertical', 'Box', 'on','FontSize', 9,'Interpreter','latex')
axis([-inf,inf, -0.5, 0.5])
tit = title('\textbf{Open-loop MPC Trajectory: Y-direction UGV velocities}','FontSize',12);
set(tit,'Interpreter','latex');
ylabel('Velocity (m/s)','FontSize',10,'Interpreter','latex')

%subplot(3,1,3)
%plot(out_3.simout.Time,out_3.simout.Data(:,26:28),'LineWidth',line_width)
%grid on;
%legend('UGV 1 Velocity $\dot{x}_{1}$', 'UGV 2 Velocity $\dot{x}_{2}$','UGV 3 Velocity $\dot{x}_{3}$', 'Location', 'northeast', 'Orientation', 'vertical', 'Box', 'on','FontSize', 9,'Interpreter','latex')
%axis([-inf,inf, -0.5, 0.5])
%tit = title('\textbf{Case 3: X-direction UGV velocities}','FontSize',12);
%set(tit,'Interpreter','latex');
%ylabel('Velocity (m/s)','FontSize',10,'Interpreter','latex')
%xlabel('Time (s)')

tightfig(hfig2);
%%
saveas(hfig2, 'figures\VAL_OL_command_1_p_inputs.fig');
% print(hfig1, '-painters', '-dsvg', 'figures\CONST_REF_FINAL_plot_outputs.svg');
print(hfig2, '-painters', '-dpdf', 'figures\VAL_OL_command_1_p_inputs.pdf');
