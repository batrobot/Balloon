function uk = MPC_Real_time_control_EXTRINSIC(ref,X,n,Ts,p,u_wind,param_vec,a_max,lastMV)

nx = 16+6*n;
ny = 5;
nu = 4*n;

nlobj = nlmpc(nx, ny, nu);
nlobj.Optimization.RunAsLinearMPC = 'timevarying';

%Define sample time, prediction and control horizons, limits
nlobj.Ts = Ts;
nlobj.PredictionHorizon = p;
nlobj.ControlHorizon = p;

nlobj.Model.NumberOfParameters = 3;
nlobj.Model.StateFcn = 'NLMPC_BalloonPend_StateFcn';
nlobj.Model.OutputFcn = 'NLMPC_BalloonPend_OutFcn';

MPC_params = cell(3,1);
MPC_params{1} = n;
MPC_params{2} = u_wind;
MPC_params{3} = param_vec;
    
%Define standard quadratic cost function weights

nlobj.Weights.ManipulatedVariablesRate = 1.0*ones(1,nu); % 1.0*.. (working)
nlobj.Weights.OutputVariables = [2 2 2 2 2]; % [5 5 5 1 1]

%Define kinematic constraints and Tension force lower bound

x_bounds = [-4 4];
y_bounds = [-4 4];
z_bound_min = 0;
omega_R_acc_max = 0;

nlobj.OutputVariables(3).Min = z_bound_min;

for i=1:1:n
    % Define tension force lower bound
    nlobj.ManipulatedVariables(i).Min = 0;
    % nlobj.ManipulatedVariables(i).Max = 0; % Only activate when T_i = 0
    % desired!!
    nlobj.ManipulatedVariables(n+i).Min = -1*a_max;
    nlobj.ManipulatedVariables(n+i).Max = a_max;
    nlobj.ManipulatedVariables(2*n+i).Min = -1*a_max;
    nlobj.ManipulatedVariables(2*n+i).Max = a_max;
    nlobj.ManipulatedVariables(3*n+i).Min = omega_R_acc_max;
    nlobj.ManipulatedVariables(3*n+i).Max = omega_R_acc_max;
    %Define Robot position bounds
    nlobj.States(16+i).Min = x_bounds(1);
    nlobj.States(16+i).Max = x_bounds(2);
    nlobj.States(16+n+i).Min = y_bounds(1);
    nlobj.States(16+n+i).Max = y_bounds(2);
end


% Evaluate inequality constraints for robot
nlobj.Optimization.CustomEqConFcn = "RopeLengthConstraintEq";

opt = nlmpcmoveopt;
opt.Parameters = MPC_params;

uk = nlmpcmove(nlobj,X,lastMV,ref,[],opt);

end