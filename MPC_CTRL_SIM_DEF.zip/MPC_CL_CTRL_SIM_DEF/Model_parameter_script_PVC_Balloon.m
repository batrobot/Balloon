%clear;

%%% SIMULINK MODEL parameters %%%%
T_s_del = -1; %s (-1: Inherited)

%%%%% BALLOON %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
n = 3;

rho_air = 1.225; %kg/m^3
rho_gas = 0.17; %kg/m^3 0.2
R_b = 1.1; %m 0.9
V_b = (4/3)*pi*R_b^3; %Geometrical assumed volume of gas m^3
g = 9.81; %kg.m/s^2
F_B_z_net = 1.75*9.81; %Newton, measured from spring scale 17.168 (1750 g)

c_D_B = 0.5;
A_cross_B = pi*R_b^2;
k_D_B = rho_air*c_D_B*A_cross_B;

m_b_env = 3.62; %kg 0.35
m_b_gas = rho_gas*V_b; %kg
m_B = m_b_gas + m_b_env;
F_B_z = F_B_z_net + m_B*g;

C_mass = 0.3;
m_v_B = m_B + C_mass*rho_air*V_b; %kg
I_B_x = ((2/3)*m_b_env*R_b^2)+((2/5)*m_b_gas*R_b^2); %kg.m^2
I_B_y = ((2/3)*m_b_env*R_b^2)+((2/5)*m_b_gas*R_b^2); %kg.m^2
I_B_z = ((2/3)*m_b_env*R_b^2)+((2/5)*m_b_gas*R_b^2); %kg.m^2

d_B_A_z = 0.14; %Offset from bottom of balloon to pendulum pivot
r_B_A_vec = [0; 0; -R_b-d_B_A_z]; %Body frame, distance to pendulum pivot point
r_B_I_mat = [R_b*(sqrt(3)/2) -1*R_b*(sqrt(3)/4) -1*R_b*(sqrt(3)/4); 0 1*R_b*(3/4) -1*R_b*(3/4); -1*R_b*(1/2) -1*R_b*(1/2) -1*R_b*(1/2)]; %30 degree configuration
x_y_ang = [0 (120/180)*pi -1*(120/180)*pi];
%%%%% PAYLOAD PENDULUM %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

m_p = 1.005; %kg
c_D_p = 1;
A_cross_p = 0.04; %m^2

k_D_P = rho_air*c_D_p*A_cross_p;
L_p = 1.64;%1; %m

%%%%%%%% ROBOT %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
m_r_b = 1.75;%5;
m_w = 0;
r_w = 0.03; %m

a_width = 0.1175;
length_tot = 0.31;
width_tot = 0.27;
b_length = 0.124;
l_w = sqrt(b_length^2+a_width^2);

% Define inverse kinematic matrix (see https://www.mathworks.com/matlabcentral/fileexchange/66586-mobile-robotics-simulation-toolbox)  %
KIN_INV = (1/r_w).*[1 -1 -1*(b_length+a_width);
                    1  1 (b_length+a_width);
                    1  1 -1*(b_length+a_width);
                    1  -1 (b_length+a_width)];


I_r_b = (1/12)*m_r_b*(a_width^2 + b_length^2);
I_r_w = 0;

L_i = 3.3;%2.5;

d_rob_x = 0;
d_rob_y = 0;
d_rob_z = 0;%0.05;
z_COG_R = 0.065;

%{
%%% Robot Motor %%
k_tau = 0.218;
R_A = 2.18;
k_e = 0.1448;
n_mot = 1;
C_mot = k_tau*k_e*n_mot/R_A;

u_max = 5; %Volts

% Motor speed PID values for SIMULINK %
kp = 2.05; %1
kI = 20;%20; %5
kD = 0;%0.005; %0.02

K_B = 0;
%}

%%% Starting positions %%%

h_p_start = 1;%out.simout.Data(1,37); %If Read out z_0 z_start_B + r_B_A_vec(3) - L_p; %
x_start_B = 0; 
y_start_B = 0;
z_start_B = -1*r_B_A_vec(3) + L_p + h_p_start; % If h_p_start not measured: out.simout.Data(1,3); 


% If measured, starting points
%x_I_start = [1.63 -0.815 -0.815];
%y_I_start = [0 1.5 -1.5];

% Derived starting points
for i = 1:1:n
    phi_I_start(i) = acos((z_start_B + r_B_I_mat(3,i) - (z_COG_R+d_rob_z))/L_i);
    T_ROPE_I_dir_0(:,i) = [-1*sin(phi_I_start(i))*cos(x_y_ang(i));
                           -1*sin(phi_I_start(i))*sin(x_y_ang(i));
                            cos(phi_I_start(i))];
    x_I_start(i) = x_start_B + (L_i*sin(phi_I_start(i))*cos(x_y_ang(i)))-d_rob_x+r_B_I_mat(1,i);
    y_I_start(i) = y_start_B + (L_i*sin(phi_I_start(i))*sin(x_y_ang(i)))-d_rob_y+r_B_I_mat(2,i);
end

%disp(x_I_start_des)
%disp(y_I_start_des)

% Assumption for a_z = 0 at start, distributed equally in z direction %
b_RHS = [0;0;(F_B_z - m_p*g - m_B*g)];
T_i_norm_start = T_ROPE_I_dir_0\b_RHS;

x_B_0_vec = [x_start_B; y_start_B; z_start_B; 0; 0; 0];
x_P_0_vec = [0;0];
v_B_0_vec = [0;0;0;0;0;0];
v_P_0_vec = [0;0];
x_R_0_vec = x_I_start.';
y_R_0_vec = y_I_start.';
theta_R_0_vec = zeros(n,1);

x_init = [x_B_0_vec;x_P_0_vec;v_B_0_vec;v_P_0_vec;x_R_0_vec;y_R_0_vec;theta_R_0_vec;zeros(3*n,1)];
u_init = [T_i_norm_start;zeros(3*n,1)];
param_vec = [F_B_z, I_B_x, I_B_y, I_B_z, L_i, L_p, reshape(r_B_I_mat.',1,[]), d_rob_x, d_rob_y, d_rob_z, reshape(r_B_A_vec,1,[]), g, k_D_B, k_D_P, m_B, m_p, m_v_B, z_COG_R];

save 'state_initial_cond.mat' x_init u_init
save 'model_params.mat' param_vec
