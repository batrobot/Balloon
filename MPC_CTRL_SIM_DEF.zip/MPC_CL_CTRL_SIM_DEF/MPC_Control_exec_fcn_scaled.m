%%%% Nested functions to control simulation execution %%%%%

function [nlobj,opt,MPC_params,CL_simout,u_cl,x_cl] = MPC_Control_exec_fcn_scaled(u_wind,param_vec,x_0,u_0,n,ref,T_steps,a_max,SL_file,Ts,p,c,MPCopt,sim_flag,prev_step)
%
% MPC controller to control Martian balloon and pendulum system %%%%
%
%Define NL MPC object %

nx = 16+6*n;
ny = 5;
nu = 4*n;

nlobj = nlmpc(nx, ny, nu);
nlobj.Optimization.RunAsLinearMPC = MPCopt;

%Define sample time, prediction and control horizons, limits
nlobj.Ts = Ts;
nlobj.PredictionHorizon = p;
nlobj.ControlHorizon = c;

nlobj.Model.NumberOfParameters = 3;
nlobj.Model.StateFcn = 'NLMPC_BalloonPend_StateFcn';
nlobj.Model.OutputFcn = 'NLMPC_BalloonPend_OutFcn';

MPC_params = cell(3,1);
MPC_params{1} = n;
MPC_params{2} = u_wind;
MPC_params{3} = param_vec;
    
%Define standard quadratic cost function weights

nlobj.Weights.ManipulatedVariablesRate = [8*ones(1,n) 2*ones(1,nu-n)]; % 1.0*.. (working) % 3,1
nlobj.Weights.OutputVariables = [1 1 1 4 4]; % [5 5 5 1 1]

%Define input and output scale factors
U_range = [4*ones(n,1); 2*a_max*ones(2*n,1); ones(n,1)];
Y_range = [max(abs(ref(:,1))); max(abs(ref(:,2))); max(abs(ref(:,3))); 0.1; 0.1]; %For constant step reference
%Y_range = [max(abs(diff(ref(:,1)))); max(abs(diff(ref(:,2)))); max(abs(diff(ref(:,3)))); 0.1; 0.1]; %For variable step reference

for i=1:nu
    nlobj.ManipulatedVariables(i).ScaleFactor = U_range(i);
end
for j=1:ny
    nlobj.OutputVariables(j).ScaleFactor = Y_range(j);
end

%Define kinematic constraints and Tension force lower bound

x_bounds = [-4 4];
y_bounds = [-4 4];
z_bound_min = 0;
omega_R_acc_max = 0;

nlobj.OutputVariables(3).Min = z_bound_min;

for i=1:1:n
    % Define tension force lower bound
    nlobj.ManipulatedVariables(i).Min = 0;
    % nlobj.ManipulatedVariables(i).Max = 0; % Only activate when T_i = 0
    % desired!!
    nlobj.ManipulatedVariables(n+i).Min = -1*a_max;
    nlobj.ManipulatedVariables(n+i).Max = a_max;
    nlobj.ManipulatedVariables(2*n+i).Min = -1*a_max;
    nlobj.ManipulatedVariables(2*n+i).Max = a_max;
    nlobj.ManipulatedVariables(3*n+i).Min = omega_R_acc_max;
    nlobj.ManipulatedVariables(3*n+i).Max = omega_R_acc_max;
    %Define Robot position bounds
    nlobj.States(16+i).Min = x_bounds(1);
    nlobj.States(16+i).Max = x_bounds(2);
    nlobj.States(16+n+i).Min = y_bounds(1);
    nlobj.States(16+n+i).Max = y_bounds(2);
end


% Evaluate inequality constraints for robot
nlobj.Optimization.CustomEqConFcn = "RopeLengthConstraintEq";

% Validate functions
rng(0)
validateFcns(nlobj,x_0,u_0,[],MPC_params)

opt = nlmpcmoveopt;
opt.Parameters = MPC_params;

% Run Closed Loop simulink model %
if(sim_flag == true)
    [CL_simout,u_cl,x_cl] = NLMPC_CL_sim_acc;
else
    [CL_simout,u_cl,x_cl] = deal(0,0,0);
end

    function [out_t,u_hist,x_hist] = NLMPC_CL_sim_acc

    %Perform first simulation
    u_hist = [];
    x_hist = [];
    out_t = [];
    info_t = [];
    lastMV = u_0;
    last_X = x_0;
    v_0 = zeros(3*n,1);
    for k=1:T_steps
        
        if T_steps > 1 && size(ref,1) > 1
            [uk,opt,info] = nlmpcmove(nlobj,last_X,lastMV,ref(k:min(k+prev_step,T_steps),:),[],opt);
            display(ref(k,:));
        else
            [uk,opt,info] = nlmpcmove(nlobj,last_X,lastMV,ref,[],opt);
            display(ref);
        end
        acc = uk(n+1:end);
        display(acc);
       
        %Define step Simulink simulation
        in = Simulink.SimulationInput(SL_file);
    
        if k == 1
            in = in.setModelParameter('StopTime', num2str(Ts), 'SaveFinalState', 'on', ...
            'LoadInitialState', 'off', 'SaveOperatingPoint', 'on',...
              'FinalStateName', 'xFinal');
        else
            in = in.setModelParameter('StopTime', num2str(k*Ts), 'SaveFinalState', 'on', ...
            'LoadInitialState', 'on', 'InitialState', 'xFinal', 'SaveOperatingPoint', 'on',...
              'FinalStateName', 'xFinal');
        end
        
        t = [(k-1)*Ts k*Ts];
        ds = Simulink.SimulationData.Dataset;
        for i=1:1:n
            u = zeros(length(t),3);
            for j = 1:1:length(t)
                u(j,:) = [acc(i) acc(n+i) acc(2*n+i)];
            end
            ds = ds.setElement(i, timeseries(u,t));
        end
        assignin('base', 'ds', ds);
        in = in.setExternalInput('ds.getElement(1),ds.getElement(2),ds.getElement(3)'); %Change depending on n
        out = sim(in);
        
        assignin('base', 'xFinal', out.get('xFinal'));
        last_X = out.states.Data(end,:).';
        lastMV = uk;
        v_0 = v_0 + acc*Ts;
    
        u_hist(k,:) = uk;
        x_hist(k,:) = last_X;
        out_t = [out_t;out];
        into_t = [info_t;info];
        assignin('base', 'out_backup', out_t);


    end

    end

end




